package it.epicode.beservice.service.test;


import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;

import it.epicode.beservice.model.StatoFattura;
import it.epicode.beservice.repository.StatoFatturaRepository;
import it.epicode.beservice.service.StatoFatturaService;


@ExtendWith(MockitoExtension.class)
class StatoFatturaServiceTest {

	@Mock StatoFatturaRepository statoFatturaRepository;
	@Mock StatoFatturaService statoFatturaService;
	
	StatoFattura stat;
	@BeforeAll
	void setUp() throws Exception {
		StatoFattura stat=new StatoFattura();
		stat.setNome("nome");
	}

	@Test
	@DisplayName("salva fattura test")
	void testSaveStatoFattura() {
		this.statoFatturaService.saveStatoFattura(null);
		assertEquals(1, this.statoFatturaRepository.findAll().size(), "salviamo uno stato e verifichiamo");
	}

}
