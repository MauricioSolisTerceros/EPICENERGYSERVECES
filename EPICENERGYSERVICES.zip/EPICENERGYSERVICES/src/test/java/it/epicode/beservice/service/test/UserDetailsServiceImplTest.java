package it.epicode.beservice.service.test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

class UserDetailsServiceImplTest {

	@BeforeAll
	static void setUpBeforeClass() throws Exception {
	}

	@Test
	void testLoadUserByUsername() {
		fail("Not yet implemented");
	}	
}
