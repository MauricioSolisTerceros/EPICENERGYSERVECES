package it.epicode.beservice.controller;

import java.time.LocalDate;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import it.epicode.beservice.model.Cliente;
import it.epicode.beservice.model.Fattura;
import it.epicode.beservice.model.StatoFattura;
import it.epicode.beservice.service.FatturaService;

@RestController
@RequestMapping("/apifattura")
public class FatturaController {

	@Autowired
	FatturaService fatturaService;

	@PostMapping("/savefattura")
	public String saveFattura(@RequestBody Fattura fattura) {
		this.fatturaService.saveFattura(fattura);
		return "fattura salvata";
	}

	@PostMapping("/updatefattura")
	public String updateFattura(Fattura fattura) {
		this.fatturaService.updateFattura(fattura);
		return "fattura aggiornata";
	}

	@GetMapping("/deletefattura")
	public String deleteFattura(Long id) {
		this.fatturaService.deleteFattura(id);
		return "fattura eliminata";
	}

	@GetMapping("/findbycliente")
	public ResponseEntity<?> findByCliente(Pageable page, Cliente cliente) {
		Page<Optional<Fattura>> find = this.fatturaService.findByCliente(page, cliente);
		if (find.hasContent()) {
			return new ResponseEntity<>(find, HttpStatus.OK);
		} else
			return new ResponseEntity<>(null, HttpStatus.NO_CONTENT);
	}
	@GetMapping("/findbystato")
	public ResponseEntity<?> findByStato(Pageable page, StatoFattura stato) {
		Page<Optional<Fattura>> find = this.fatturaService.findByStato(page, stato);
		if (find.hasContent()) {
			return new ResponseEntity<>(find, HttpStatus.OK);
		} else
			return new ResponseEntity<>(null, HttpStatus.NO_CONTENT);
	}
	@GetMapping("/findbydata")
	public ResponseEntity<?> findByData(Pageable page, @RequestParam LocalDate data) {
		Page<Optional<Fattura>> find = this.fatturaService.findByData(page,data);
		if (find.hasContent()) {
			return new ResponseEntity<>(find, HttpStatus.OK);
		} else
			return new ResponseEntity<>(null, HttpStatus.NO_CONTENT);
	}
	@GetMapping("/findbyanno")
	public ResponseEntity<?> findByAnno(Pageable page, @RequestParam LocalDate anno) {
		Page<Optional<Fattura>> find = this.fatturaService.findByAnno(page, anno);
		if (find.hasContent()) {
			return new ResponseEntity<>(find, HttpStatus.OK);
		} else
			return new ResponseEntity<>(null, HttpStatus.NO_CONTENT);
	}
	@GetMapping("/findbyimporto")
	public ResponseEntity<?> findByimporto(Pageable page,@RequestParam String maxP, @RequestParam String minP) {
		Double min=Double.parseDouble(minP);
		Double max=Double.parseDouble(maxP);
		Page<Optional<Fattura>> find = this.fatturaService.findByImporto(page, max, min);
		if (find.hasContent()) {
			return new ResponseEntity<>(find, HttpStatus.OK);
		} else
			return new ResponseEntity<>(null, HttpStatus.NO_CONTENT);
	}
	
	

}
