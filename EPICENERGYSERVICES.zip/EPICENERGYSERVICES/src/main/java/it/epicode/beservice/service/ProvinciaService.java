package it.epicode.beservice.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import it.epicode.beservice.model.Provincia;
import it.epicode.beservice.repository.ProvinciaRepository;

@Service
public class ProvinciaService {

	@Autowired
	ProvinciaRepository provinciaRepository;
	
	public void saveProvincia (Provincia provincia) {
		this.provinciaRepository.save(provincia);
	}
	public void deleteProvincia (Long id) {
		this.provinciaRepository.deleteById(id);
	}
	public void updateProvincia(Provincia provincia) {
		Provincia p=this.provinciaRepository.findByIdProvincia(provincia.getId());
		p.setId(provincia.getId());
		p.setNome(provincia.getNome());
		p.setSigla(provincia.getSigla());
		this.provinciaRepository.flush();
	}
	public Provincia findByNome(String nome) {
		return this.provinciaRepository.findByNome(nome);
	}
}
