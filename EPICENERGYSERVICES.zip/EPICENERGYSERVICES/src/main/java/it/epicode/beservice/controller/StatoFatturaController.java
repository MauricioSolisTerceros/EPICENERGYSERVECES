package it.epicode.beservice.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import it.epicode.beservice.model.StatoFattura;
import it.epicode.beservice.service.StatoFatturaService;

@RestController
@RequestMapping("/apistatofattura")
public class StatoFatturaController {
	
	@Autowired
	StatoFatturaService statoFatturaService;
	
	@PostMapping("/savestatofattura")
	public String saveStatoFattura(@RequestBody StatoFattura statoFattura) {
		this.statoFatturaService.saveStatoFattura(statoFattura);
		return "stato fattura salvata";
	}

}
