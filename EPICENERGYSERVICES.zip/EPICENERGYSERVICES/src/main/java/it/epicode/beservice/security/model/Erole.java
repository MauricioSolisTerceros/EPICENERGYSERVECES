package it.epicode.beservice.security.model;

public enum Erole {

	ROLE_USER,
	ROLE_ADMIN;
}
