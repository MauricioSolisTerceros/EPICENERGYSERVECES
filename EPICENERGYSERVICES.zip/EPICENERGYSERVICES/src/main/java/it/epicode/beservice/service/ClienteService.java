package it.epicode.beservice.service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import it.epicode.beservice.model.Cliente;
import it.epicode.beservice.repository.ClienteRepository;

@Service
public class ClienteService {

	@Autowired
	ClienteRepository clienteRepository;

	public void saveCliente(Cliente cliente) {
		this.clienteRepository.save(cliente);
	}

	public void deleteCliente(Long id) {
		this.clienteRepository.deleteById(id);
	}

	public void updateCliente(Cliente cliente) {
		Cliente c = this.clienteRepository.findByIdCliente(cliente.getId());
		c.setCognomeContatto(cliente.getCognomeContatto());
		c.setDataInserimento(cliente.getDataInserimento());
		c.setDataUltimoContatto(cliente.getDataUltimoContatto());
		c.setEmail(cliente.getEmail());
		c.setEmailContatto(cliente.getEmailContatto());
		c.setFatturatoAnnuale(cliente.getFatturatoAnnuale());
		c.setFatture(cliente.getFatture());
		c.setId(cliente.getId());
		c.setIndirizzoSedeLegale(cliente.getIndirizzoSedeLegale());
		c.setIndirizzoSedeOperativa(cliente.getIndirizzoSedeOperativa());
		c.setNomeContatto(cliente.getNomeContatto());
		c.setPartitaIva(cliente.getPartitaIva());
		c.setPec(cliente.getPec());
		c.setRagioneSociale(cliente.getRagioneSociale());
		c.setTelefono(cliente.getTelefono());
		c.setTelefonoContatto(cliente.getTelefonoContatto());
		c.setTipoCliente(cliente.getTipoCliente());
		this.clienteRepository.delete(c);
	}

	public Page<Optional<Cliente>> findByOrderByRagioneSociale(Pageable page) {
		return this.clienteRepository.findByOrderByRagioneSociale(page);
	}

	public Page<Optional<Cliente>> findByOrderByDataInserimento(Pageable page) {
		return this.clienteRepository.findByOrderByDataInserimento(page);
	}

	public Page<Optional<Cliente>> findByOrderByFatturatoAnnuale(Pageable page) {
		return this.clienteRepository.findByOrderByFatturatoAnnuale(page);
	}

	public Page<Optional<Cliente>> findByOrderByDataUltimoContatto(Pageable page) {
		return this.clienteRepository.findByOrderByDataUltimoContatto(page);
	}

	public Page<Optional<Cliente>> findByOrderByIndirizzoSedeLegaleComuneProvincia(
			Pageable page) {
		return this.clienteRepository
				.findByOrderByIndirizzoSedeLegaleComuneProvincia(page);
	}

	public Page<Optional<Cliente>> findByfatturatoAnnuale(Pageable page, Double fatturato) {
		return this.clienteRepository.findByFatturatoAnnuale(page, fatturato);
	}

	public Page<Optional<Cliente>> findBydataInserimento(Pageable page, LocalDate data) {
		return this.clienteRepository.findByDataInserimento(page, data);
	}

	public Page<Optional<Cliente>> findByRagioneSociale(Pageable page, String nome) {
		return this.clienteRepository.findByRagioneSociale(page, nome);
	}

	public List<Cliente> findAll() {
		return this.clienteRepository.findAll();
	}

	public Page<Optional<Cliente>> findByDataUltimoContatto(Pageable page, LocalDate data) {
		return this.clienteRepository.findByDataUltimoContatto(page, data);
	}
	public Cliente findById(Long id) {
		return this.clienteRepository.findByIdCliente(id);
	}

}