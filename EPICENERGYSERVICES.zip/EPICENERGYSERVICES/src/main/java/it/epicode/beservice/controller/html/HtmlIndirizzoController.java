package it.epicode.beservice.controller.html;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import it.epicode.beservice.model.Cliente;
import it.epicode.beservice.model.Indirizzo;
import it.epicode.beservice.service.ClienteService;
import it.epicode.beservice.service.IndirizzoService;

@Controller
@RequestMapping("/apiindirizzohtml")
public class HtmlIndirizzoController {
	
	@Autowired
	ClienteService clienteService;
	
	@Autowired
	IndirizzoService indirizzoService;

	@GetMapping("showindirizzo/{id}/{indirizzo}")
	public ModelAndView showIndirizzo (@PathVariable Long id, @ModelAttribute Indirizzo indirizzo, ModelAndView model) {
		Cliente c= clienteService.findById(id);
		model.addObject("idcliente", c.getId());
		if(c.getIndirizzoSedeLegale().equals(indirizzo)) {
			model.setViewName("showindirizzo");
			model.addObject("indirizzo",c.getIndirizzoSedeLegale());
			return model;
		}else {
			model.setViewName("showindirizzo");
			model.addObject("indirizzo",c.getIndirizzoSedeOperativa());
			return model;
		}
			
	}
	@GetMapping("/updateindirizzo/{indirizzo})")
	public String updateIndirizzo (@ModelAttribute Indirizzo indirizzo, ModelAndView view) { 
		indirizzoService.updateIndirizzo(indirizzo);
		return "/findall";
	}
}
