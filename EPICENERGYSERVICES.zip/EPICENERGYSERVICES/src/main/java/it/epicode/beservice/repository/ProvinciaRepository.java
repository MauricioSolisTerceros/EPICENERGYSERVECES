package it.epicode.beservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import it.epicode.beservice.model.Provincia;

@Repository
public interface ProvinciaRepository extends JpaRepository<Provincia, Long> {
	
	@Query("select p from Provincia p where p.id=:id")
	Provincia findByIdProvincia(Long id);

	Provincia findByNome(String nome);
}
