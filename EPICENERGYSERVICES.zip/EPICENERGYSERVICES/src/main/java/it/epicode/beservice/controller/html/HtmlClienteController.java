package it.epicode.beservice.controller.html;


import java.util.List;
import java.util.Optional;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import it.epicode.beservice.model.Cliente;
import it.epicode.beservice.model.Indirizzo;
import it.epicode.beservice.service.ClienteService;
import it.epicode.beservice.service.IndirizzoService;

@Controller
@RequestMapping("/apiclientehtml")
public class HtmlClienteController {

	@Autowired
	ClienteService clienteService;

	@Autowired
	IndirizzoService indirizzoService;
	
	@PostMapping("/savecliente")
	public String saveCliente(Cliente cli) {
		this.clienteService.saveCliente(cli);
		return "cliente salvato";
	}

	@PostMapping("/updatecliente")
	public String updateCliente(Cliente cli) {
		this.clienteService.updateCliente(cli);
		return "cliente aggiornato";
	}

	@GetMapping("/deletecliente/{id}")
	public String deleteCliente(@PathVariable Long id) {
		this.clienteService.deleteCliente(id);
		return "cliente cancellato";
	}

	@GetMapping("/findbyorderbynome/{pageNo}")
	public ModelAndView findByOrderByRagioneSociale(Pageable page,
			@RequestParam(required = false) int pageNo) {
		Page<Optional<Cliente>> find = this.clienteService.findByOrderByRagioneSociale(page);
		List<Optional<Cliente>> list = find.getContent();
		if (find.hasContent()) {
			ModelAndView view = new ModelAndView("list.html");
			view.addObject("list",list);
			view.addObject("currentPage", pageNo);
			view.addObject("totalPages",find.getTotalPages());
			view.addObject("allItems",find.getTotalElements());
			view.addObject("find", find);
			return view;
		} else {
			ModelAndView error = new ModelAndView("error.html");
			return error;
		}
	}
	
	@GetMapping("/findall")
	public ModelAndView findAll(Pageable page) {
		List<Cliente> find = this.clienteService.findAll();
		if (!(find.isEmpty())) {
			ModelAndView view = new ModelAndView("list.html");
			view.addObject("find", find);
			return view;
		} else {
			ModelAndView badrequest = new ModelAndView("error.html");
			return badrequest;
		}
	}
	
	@GetMapping("/showindirizzi/{id}")
	public ModelAndView showIndirizzoLegale(@PathVariable Long id, @ModelAttribute Indirizzo indirizzo, ModelAndView model) {
		Cliente c= this.clienteService.findById(id);
		
		if(c.getIndirizzoSedeLegale().equals(indirizzo)) {
			model.setViewName("showindirizzo");
			model.addObject("indirizzo", c.getIndirizzoSedeLegale());
			return model;
		}else {
			model.setViewName("showindirizzo");
			model.addObject("indirizzo",c.getIndirizzoSedeOperativa());
		}
		return model;
		
	}

//	@GetMapping("/findbyorderfatturatoannuale")
//	public ModelAndView findByOrderByFatturatoAnnuale(Pageable page) {
//		Page<Optional<Cliente>> find = this.clienteService.findByOrderByFatturatoAnnuale(page);
//		if (find.hasContent()) {
//			ModelAndView view = new ModelAndView("list.html");
//			view.addObject("find", find);
//			return view;
//		} else {
//			ModelAndView error = new ModelAndView("error.html");
//			return error;
//		}
//	}
//
//	@GetMapping("/findbyorderdatainserimento")
//	public ResponseEntity<?> findByDataInserimento(Pageable page) {
//		Page<Optional<Cliente>> find = this.clienteService.findByOrderByDataInserimento(page);
//		if (find.hasContent()) {
//			return new ResponseEntity<>(find, HttpStatus.OK);
//		} else
//			return new ResponseEntity<>(null, HttpStatus.NO_CONTENT);
//	}
//
//	@GetMapping("/findbyorderbydataultimocontatto")
//	public ResponseEntity<?> findByOrderByDataUltimoContatto(Pageable page) {
//		Page<Optional<Cliente>> find = this.clienteService.findByOrderByDataUltimoContatto(page);
//		if (find.hasContent()) {
//			return new ResponseEntity<>(find, HttpStatus.OK);
//		} else
//			return new ResponseEntity<>(null, HttpStatus.NO_CONTENT);
//	}
//
//	@GetMapping("/findbyorderbyordineprovinciasedelegale")
//	public ResponseEntity<?> findByOrderByIndirizzoSedeLegaleComuneProvincia(Pageable page) {
//		Page<Optional<Cliente>> find = this.clienteService.findByOrderByIndirizzoSedeLegaleComuneProvincia(page);
//		if (find.hasContent()) {
//			return new ResponseEntity<>(find, HttpStatus.OK);
//		} else
//			return new ResponseEntity<>(null, HttpStatus.NO_CONTENT);
//	}
//
//	@GetMapping("/finbyfatturatoannuale")
//	public ModelAndView findByFatturatoAnnuale(Pageable page, @RequestParam Double fatturato) {
//		Page<Optional<Cliente>> find = this.clienteService.findByfatturatoAnnuale(page, fatturato);
//		if (find.hasContent()) {
//			ModelAndView view = new ModelAndView("list.html");
//			view.addObject("find", find);
//			return view;
//		} else {
//			ModelAndView error = new ModelAndView("error.html");
//			return error;
//		}
//	}
//
//	@GetMapping("/findbydatainserimento")
//	public ModelAndView findByDataInserimento(Pageable page,
//			@RequestParam @DateTimeFormat(pattern = "dd-MM-yyyy") LocalDate data) {
//		Page<Optional<Cliente>> find = this.clienteService.findBydataInserimento(page, data);
//		if (find.hasContent()) {
//			ModelAndView view = new ModelAndView("list.html");
//			view.addObject("find", find);
//			return view;
//		} else {
//			ModelAndView error = new ModelAndView("error.html");
//			return error;
//		}
//	}
//	@GetMapping("/findbydataultimocontatto")
//	public ModelAndView findByDataUltimoContatto(Pageable page,
//			@RequestParam @DateTimeFormat(pattern = "dd-MM-yyyy") LocalDate data) {
//		Page<Optional<Cliente>> find = this.clienteService.findByDataUltimoContatto(page, data);
//		if (find.hasContent()) {
//			ModelAndView view = new ModelAndView("list.html");
//			view.addObject("find", find);
//			return view;
//		} else {
//			ModelAndView error = new ModelAndView("error.html");
//			return error;
//		}
//	}
//
//	@GetMapping("/findall")
//	public ModelAndView findAll(Pageable page) {
//		List<Cliente> find = this.clienteService.findAll();
//		if (!(find.isEmpty())) {
//			ModelAndView view = new ModelAndView("list.html");
//			view.addObject("find", find);
//			return view;
//		} else {
//			ModelAndView badrequest = new ModelAndView("error.html");
//			return badrequest;
//		}
//	}

}
